-- 1. Tạo Database (nếu chưa tồn tại)
IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = N'PolyOE')
BEGIN
    CREATE DATABASE PolyOE;
END
GO

USE PolyOE;
GO

-- 2. Xóa các bảng nếu tồn tại
IF OBJECT_ID('dbo.Favorites', 'U') IS NOT NULL DROP TABLE dbo.Favorites;
IF OBJECT_ID('dbo.Shares', 'U') IS NOT NULL DROP TABLE dbo.Shares;
IF OBJECT_ID('dbo.Report', 'U') IS NOT NULL DROP TABLE dbo.Report;
IF OBJECT_ID('dbo.Users', 'U') IS NOT NULL DROP TABLE dbo.Users;
IF OBJECT_ID('dbo.Videos', 'U') IS NOT NULL DROP TABLE dbo.Videos;
GO

-- 3. Tạo bảng chính
CREATE TABLE Users(
    Id NVARCHAR(50) PRIMARY KEY,
    Password NVARCHAR(255) NOT NULL,
    Email NVARCHAR(100) UNIQUE NOT NULL,
    Fullname NVARCHAR(100),
    Admin BIT DEFAULT 0
);

CREATE TABLE Videos(
    Id NVARCHAR(50) PRIMARY KEY,
    Title NVARCHAR(255) NOT NULL,
    Poster NVARCHAR(255),
    Views INT DEFAULT 0,
    Description NVARCHAR(MAX),
    Category NVARCHAR(50) NULL,
    Active BIT DEFAULT 1
);

CREATE TABLE Favorites (
    Id BIGINT IDENTITY(1,1) PRIMARY KEY,
    UserId NVARCHAR(50) NOT NULL,
    VideoId NVARCHAR(50) NOT NULL,
    LikeDate DATE DEFAULT GETDATE(),
    FOREIGN KEY (UserId) REFERENCES Users(Id) ON DELETE CASCADE,
    FOREIGN KEY (VideoId) REFERENCES Videos(Id) ON DELETE CASCADE
);

CREATE TABLE Shares (
    Id BIGINT IDENTITY(1,1) PRIMARY KEY,
    UserId NVARCHAR(50) NOT NULL,
    VideoId NVARCHAR(50) NOT NULL,
    Emails NVARCHAR(255),
    ShareDate DATE DEFAULT GETDATE(),
    FOREIGN KEY (UserId) REFERENCES Users(Id) ON DELETE CASCADE,
    FOREIGN KEY (VideoId) REFERENCES Videos(Id) ON DELETE CASCADE
);

CREATE TABLE Report (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Groupp NVARCHAR(100),
    Likes INT DEFAULT 0,
    Newest NVARCHAR(255),
    Oldest NVARCHAR(255),
    Date DATE DEFAULT GETDATE()
);
GO

-- 4. Chèn dữ liệu Users
INSERT INTO Users (Id, Password, Fullname, Email, Admin) VALUES
(N'NV001', N'ABC', N'LEE ANH TU', N'TULA12@FE.EDU.VN', 1),
(N'NV002', N'123', N'ANH TÚ', N'leanhtu@GMAIL.COM', 1),
(N'NV003', N'321', N'Nguyễn Nhật Cao Thăng', N'thangncc@fpt.edu.vn', 0),
(N'NV004', N'321', N'Phan Nguyễn Đăng Trường', N'truongpnd@fpt.edu.vn', 0),
(N'NV006', N'123', N'Vương Ngọc Thanh Loan', N'loan@gmail.com', 0),
(N'NV007', N'123', N'Nguyễn Thanh Vũ', N'vu@gmail.com', 0),
(N'NV008', N'123', N'Phạm Đồng Đại', N'dai@gmail.com', 0),
(N'NV009', N'321', N'Trần Thị Ánh Tuyết', N'tuyet@gmail.com', 0),
(N'NV010', N'321', N'Trần Thị Ánh Tuyết2', N'tuyet2@gmail.com', 0),
(N'NV011', N'pass11', N'Nguyễn Văn Tèo', N'teonv@gmail.com', 0),
(N'NV012', N'pass12', N'Nguyễn Văn B', N'vanb@gmail.com', 0),
(N'NV013', N'pass13', N'Nguyễn Văn C', N'vanc@gmail.com', 0),
(N'NV014', N'pass14', N'Nguyễn Văn D', N'vand@gmail.com', 0),
(N'NV015', N'pass15', N'Nguyễn Văn E', N'vane@gmail.com', 0);
GO

-- 5. Chèn dữ liệu Videos
INSERT INTO Videos (Id, Title, Poster, Description, Active, Views, Category) VALUES
(N'vd001', N'W/n - 3107 3 (Official Video) ft. Nâu, Duongg, Titie', N'kfw7MYah2n0', N'Sáng tác & Music Producer: W/n Rap: Nâu...', 1, 100, 'Music'),
(N'vd002', N'QUÂN A.P - BÔNG HOA ĐẸP NHẤT', N'e2Xx7WcvEns', N'BÔNG HOA ĐẸP NHẤT Singer: Quân A.P...', 1, 100, 'Music'),
(N'vd003', N'Ánh Sao Và Bầu Trời - T.R.I', N'9vaLkYElidg', N'Performer: T.R.I...', 1, 100, 'Music'),
(N'vd004', N'hieuthuhai - ngủ một mình', N'1OJQdxT6WHE', N'Produced by Dargon...', 1, 100, 'Music'),
(N'vd005', N'Lửng Lơ | Masew x Bray', N'HehotFZ8BGo', N'Một sản phẩm thực hiện bởi Great Entertainment...', 1, 100, 'Music'),
(N'vd006', N'MONO - Waiting For You', N'CHw1b_1LVBA', N'Nghệ sĩ biểu diễn: MONO...', 1, 100, 'Music'),
(N'vd007', N'HIEUTHUHAI - Vệ Tinh', N'TTwlhJzXHo4', N'Artist: HIEUTHUHAI...', 1, 100, 'Music'),
(N'vd008', N'An Thần (ft. Thắng) | Low G', N'J7eYhM6wXPo', N'Produced by Thắng...', 1, 100, 'Music');
GO

-- 6. Chèn dữ liệu Favorites
SET IDENTITY_INSERT [dbo].[Favorites] ON;
INSERT INTO Favorites (Id, VideoId, UserId, LikeDate) VALUES
(1, N'vd001', N'NV001', '2023-03-10'),
(2, N'vd001', N'NV002', '2023-03-15'),
(3, N'vd002', N'NV003', '2023-03-20'),
(4, N'vd002', N'NV004', '2023-03-25'),
(5, N'vd003', N'NV001', '2024-01-10');
SET IDENTITY_INSERT [dbo].[Favorites] OFF;
GO

-- 7. Chèn dữ liệu Shares
INSERT INTO Shares (UserId, VideoId, Emails, ShareDate) VALUES
(N'NV001', N'vd001', N'abc@gmail.com', '2023-03-10'),
(N'NV002', N'vd002', N'def@gmail.com', '2023-03-15'),
(N'NV003', N'vd003', N'ghi@gmail.com', '2023-03-20'),
(N'NV004', N'vd004', N'jkl@gmail.com', '2023-03-25'),
(N'NV001', N'vd005', N'mno@gmail.com', '2024-01-10');
GO

-- 8. Stored Procedure spFavoriteByYear
IF OBJECT_ID('dbo.spFavoriteByYear') IS NOT NULL
    DROP PROCEDURE dbo.spFavoriteByYear;
GO

CREATE PROC [dbo].[spFavoriteByYear](@year INT)
AS
BEGIN
	SELECT
		v.Title AS 'groupp',
		v.Category,
		COUNT(f.Id) AS 'likes',
        MAX(f.LikeDate) AS 'newest',
        MIN(f.LikeDate) AS 'oldest'
	FROM Favorites f
	JOIN Videos v ON f.VideoId = v.Id
	WHERE YEAR(f.LikeDate) = @year
	GROUP BY v.Title, v.Category;
END
GO
