package poly.com.dao;

import java.util.List;
import poly.com.entity.Favorite;
import poly.com.entity.User;
import poly.com.entity.Video;
import java.util.List;
import poly.com.entity.Favorite;

public interface FavoriteIDAO extends ICRUD<Favorite, Long> {

	List<Video> findFavoriteVideosByUserId(String userId);

	List<Favorite> findAllFavoritesByVideoId(String videoId);

	List<Favorite> findAllWithDetails();
	
	List<User> findUsersByVideoId(String videoId);
}