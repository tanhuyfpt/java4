package poly.com.dao;

import java.util.List;
import jakarta.persistence.TypedQuery;
import poly.com.entity.User;

public class UserDAOImpl extends AbstractDAO<User, String> implements UserIDAO {

	public UserDAOImpl() {
		super(User.class);
	}

	@Override
	public List<User> findByEmailDomain(String domain) {
		return executeQuery(em -> {
			String jpql = "SELECT u FROM User u WHERE u.email LIKE :email";
			TypedQuery<User> query = em.createQuery(jpql, User.class);
            query.setParameter("email", "%" + domain);
            return query.getResultList();
		});
	}

	@Override
	public List<User> findAdmins() {
		return executeQuery(em -> {
            String jpql = "SELECT u FROM User u WHERE u.admin = true";
            TypedQuery<User> query = em.createQuery(jpql, User.class);
            return query.getResultList();
        });
	}

	@Override
	public List<User> findUsersInPage(int pageNumber, int pageSize) {
		return executeQuery(em->{
			String jpql = "SELECT u FROM User u ORDER BY u.id";
			TypedQuery<User> query = em.createQuery(jpql, User.class);
			query.setFirstResult(pageNumber * pageSize);
            query.setMaxResults(pageSize);
			return query.getResultList();
		});
	}
	
	@Override
	public List<User> findByEmail(String email) {
	    return executeQuery(em -> {
	        String jpql = "SELECT u FROM User u WHERE UPPER(u.email) LIKE UPPER(:email)";
	        TypedQuery<User> query = em.createQuery(jpql, User.class);
	        query.setParameter("email", "%" + email + "%");
	        return query.getResultList();
	    });
	}
	
	@Override
	public User findUserBySearchTerm(String term) {
	    return executeQuery(em -> {
	        String searchTerm = term.trim();
	        
	        String jpql = "SELECT u FROM User u LEFT JOIN FETCH u.favorites f WHERE " // <<< THÊM JOIN FETCH
	                    + "UPPER(u.id) = UPPER(:term) OR "
	                    + "UPPER(u.fullname) = UPPER(:term) OR "
	                    + "UPPER(u.email) = UPPER(:term)";
	        
	        TypedQuery<User> query = em.createQuery(jpql, User.class);
	        query.setParameter("term", searchTerm);
	        query.setMaxResults(1); 
	        
	        List<User> results = query.getResultList();
	        
	        // Hibernate có thể trả về nhiều bản ghi User nếu có nhiều Favorite. 
	        // Dùng distinctResult() hoặc chỉ lấy phần tử đầu tiên sau khi truy vấn.
	        return results.isEmpty() ? null : results.get(0);
	    });
	}
	
	//Bai1 Lab5
	@Override
	public User findByIdOrEmail(String term) {
	    return executeQuery(em -> {
	        String jpql = "SELECT u FROM User u WHERE UPPER(u.id) = UPPER(:term) OR UPPER(u.email) = UPPER(:term)";
	        TypedQuery<User> query = em.createQuery(jpql, User.class);
	        query.setParameter("term", term.trim());
	        List<User> results = query.getResultList();
	        return results.isEmpty() ? null : results.get(0);
	    });
	}

}
