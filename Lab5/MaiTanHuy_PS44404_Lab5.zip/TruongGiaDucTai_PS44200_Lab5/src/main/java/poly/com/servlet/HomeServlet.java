package poly.com.servlet;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import poly.com.dao.VideoDAOImpl;
import poly.com.entity.Video;

@WebServlet(urlPatterns = {"/index", "/home"}, name = "HomeServlet")
public class HomeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	private VideoDAOImpl videoDAO;

    @Override
    public void init() throws ServletException {
        super.init();
        videoDAO = new VideoDAOImpl();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		
		try {
			// Lấy danh sách video đang hoạt động và video xem nhiều nhất
			List<Video> activeVideos = videoDAO.findActiveVideos();
			List<Video> topViewedVideos = videoDAO.findTopNViewedVideos(6); // Lấy Top 6
			
			// Đặt dữ liệu vào request scope
			request.setAttribute("activeVideos", activeVideos);
			request.setAttribute("topViewedVideos", topViewedVideos);
			
			request.setAttribute("pageTitle", "Trang Chủ - VideoTube");
			
			// Chuyển tiếp đến trang JSP
			request.getRequestDispatcher("/views/index.jsp").forward(request, response);
			
		} catch (Exception e) {
			e.printStackTrace();
			response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, 
					"Lỗi hệ thống khi tải trang chủ.");
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		doGet(request, response);
	}
}