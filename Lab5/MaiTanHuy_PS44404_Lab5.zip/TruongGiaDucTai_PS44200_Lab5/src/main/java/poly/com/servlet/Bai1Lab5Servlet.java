package poly.com.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import poly.com.dao.*;
import poly.com.entity.User;
import poly.com.entity.Video;

import java.io.IOException;
import java.util.List;

@WebServlet("/lab5/bai1")
public class Bai1Lab5Servlet extends HttpServlet {
    private UserIDAO userDao;
    private VideoIDAO videoDao;
    private ShareIDAO shareDao;

    @Override
    public void init() throws ServletException {
        userDao = new UserDAOImpl();
        videoDao = new VideoDAOImpl();
        shareDao = new ShareDAOImpl();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        // 1. Tìm User theo id hoặc email
        String userKey = request.getParameter("userKey");
        if(userKey != null && !userKey.isEmpty()) {
            User user = userDao.findByIdOrEmail(userKey);
            request.setAttribute("searchUser", user);
        }

        // 2. Tìm Video theo title keyword
        String keyword = request.getParameter("keyword");
        if(keyword != null && !keyword.isEmpty()) {
            List<Video> videosByKeyword = videoDao.findByTitleKeyword(keyword);
            request.setAttribute("videosByKeyword", videosByKeyword);
        }

        // 3. Top 10 video nhiều lượt thích
        List<Object[]> topLikedVideos = videoDao.findTop10MostLiked();
        request.setAttribute("topLikedVideos", topLikedVideos);

        // 4. Video không được ai thích
        List<Video> noLikesVideos = videoDao.findVideosNoLikes();
        request.setAttribute("noLikesVideos", noLikesVideos);

        // 5. Video được chia sẻ năm 2024
        List<Object[]> shared2024Videos = videoDao.findSharedIn2024();
        request.setAttribute("shared2024Videos", shared2024Videos);

        // 6. Thông tin chia sẻ tổng hợp từng video
        List<Object[]> shareSummary = shareDao.getShareSummary();
        request.setAttribute("shareSummary", shareSummary);

        request.getRequestDispatcher("/views/Lab5_bai1.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response); // POST gọi GET
    }
}
