package poly.com.dao;

import java.util.List;
import jakarta.persistence.TypedQuery;
import poly.com.entity.Share;

public class ShareDAOImpl extends AbstractDAO<Share, Long> implements ShareIDAO {

    public ShareDAOImpl() {
        super(Share.class);
    }

    @Override
    public List<Share> findSharesByVideoId(String videoId) {
        return executeQuery(em -> {
            String jpql = "SELECT s FROM Share s WHERE s.video.id = :videoId ORDER BY s.shareDate DESC";
            TypedQuery<Share> query = em.createQuery(jpql, Share.class);
            query.setParameter("videoId", videoId);
            return query.getResultList();
        });
    }

    @Override
    public List<Share> findSharesByUserId(String userId) {
        return executeQuery(em -> {
            String jpql = "SELECT s FROM Share s WHERE s.user.id = :userId ORDER BY s.shareDate DESC";
            TypedQuery<Share> query = em.createQuery(jpql, Share.class);
            query.setParameter("userId", userId);
            return query.getResultList();
        });
    }

    @Override
    public List<Object[]> getShareSummary() {
        return executeQuery(em -> {
            String jpql = "SELECT s.video.title, COUNT(s.id), MIN(s.shareDate), MAX(s.shareDate) " +
                          "FROM Share s " +
                          "GROUP BY s.video.id, s.video.title " +
                          "ORDER BY s.video.title ASC";
            return em.createQuery(jpql, Object[].class).getResultList();
        });
    }


}