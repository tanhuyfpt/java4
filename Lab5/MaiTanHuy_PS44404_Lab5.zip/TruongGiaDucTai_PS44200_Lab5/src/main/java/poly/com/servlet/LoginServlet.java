package poly.com.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import poly.com.dao.*;
import poly.com.entity.User;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/auth/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserIDAO userDao = new UserDAOImpl();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Chỉ hiển thị form login
        request.getRequestDispatcher("/views/login.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String term = request.getParameter("term"); // username hoặc email
        String password = request.getParameter("password");

        User user = userDao.findByIdOrEmail(term);

        if (user != null && user.getPassword().equals(password)) {
            // Lưu thông tin user vào session
            request.getSession().setAttribute("userLogin", user);
            response.sendRedirect(request.getContextPath() + "/index"); // chuyển đến trang chính
        } else {
            // Đăng nhập thất bại
            request.setAttribute("error", "Username/email hoặc mật khẩu không đúng!");
            request.getRequestDispatcher("/views/login.jsp").forward(request, response);
        }
    }
}
