package poly.com.dao;

import java.util.List;
import jakarta.persistence.TypedQuery;
import poly.com.entity.Video;

public class VideoDAOImpl extends AbstractDAO<Video, String> implements VideoIDAO {

    public VideoDAOImpl() {
        super(Video.class);
    }

    @Override
    public List<Video> findActiveVideos() {
        return executeQuery(em -> {
            String jpql = "SELECT v FROM Video v WHERE v.active = true";
            TypedQuery<Video> query = em.createQuery(jpql, Video.class);
            return query.getResultList();
        });
    }

    @Override
    public List<Video> findTopNViewedVideos(int topN) {
        return executeQuery(em -> {
            String jpql = "SELECT v FROM Video v ORDER BY v.views DESC";
            TypedQuery<Video> query = em.createQuery(jpql, Video.class);
            query.setMaxResults(topN);
            return query.getResultList();
        });
    }
    
    //Bai1 Lab5
    @Override
    public List<Video> findByTitleKeyword(String keyword) {
        return executeQuery(em -> {
            String jpql = "SELECT v FROM Video v WHERE UPPER(v.title) LIKE UPPER(:keyword)";
            TypedQuery<Video> query = em.createQuery(jpql, Video.class);
            query.setParameter("keyword", "%" + keyword.trim() + "%");
            return query.getResultList();
        });
    }
    
    @Override
    public List<Object[]> findTop10MostLiked() {
        return executeQuery(em -> {
            String jpql = "SELECT v, COUNT(f.id) AS likeCount " +
                          "FROM Favorite f JOIN f.video v " +
                          "GROUP BY v.id, v.title, v.category, v.description, v.poster, v.views, v.active " +
                          "ORDER BY COUNT(f.id) DESC";
            TypedQuery<Object[]> query = em.createQuery(jpql, Object[].class);
            query.setMaxResults(10);
            return query.getResultList();
        });
    }


    @Override
    public List<Video> findVideosNoLikes() {
        return executeQuery(em -> {
            String jpql = "SELECT v FROM Video v WHERE v.favorites IS EMPTY";
            TypedQuery<Video> query = em.createQuery(jpql, Video.class);
            return query.getResultList();
        });
    }

    @Override
    public List<Object[]> findSharedIn2024() {
        return executeQuery(em -> {
            String jpql = "SELECT v, COUNT(s.id), MIN(s.shareDate), MAX(s.shareDate) " +
                          "FROM Share s JOIN s.video v " +
                          "WHERE YEAR(s.shareDate) = 2024 " +
                          "GROUP BY v.id, v.title, v.category, v.description, v.poster, v.views, v.active " +
                          "ORDER BY MIN(s.shareDate)";
            TypedQuery<Object[]> query = em.createQuery(jpql, Object[].class);
            return query.getResultList();
        });
    }

}