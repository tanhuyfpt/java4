package com.poly.servlet;

import java.io.IOException;
import java.util.List;

import com.poly.dao.FovoritesDao;
import com.poly.entity.Favorite;
import com.poly.entity.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet("/id-search")
public class FavoriteServlet extends HttpServlet 
{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		req.getRequestDispatcher("/views/id-search.jsp").forward(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		 // Lấy userId từ form
        String userId = req.getParameter("id");
        // Gọi DAO lấy danh sách favorite
        List<Favorite> favorites = null;
		try {
			//favorites = FovoritesDao.findFavoritesByUserId(userId);
			favorites = FovoritesDao.findFavoritesByUserIdJPQL(userId);
			
		
		} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

        // Nếu có favorite, lấy thông tin user
      
            User user = favorites.get(0).getUser();
            req.setAttribute("user", user);
            req.setAttribute("favorite", favorites);
      

        // Forward sang JSP
        req.getRequestDispatcher("/views/id-search.jsp").forward(req, resp);
		
	}
	
	
	
}
