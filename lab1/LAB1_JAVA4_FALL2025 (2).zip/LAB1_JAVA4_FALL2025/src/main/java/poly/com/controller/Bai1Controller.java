package poly.com.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Servlet implementation class Bai1Controller
 */
@WebServlet({ "/bai1", "/bai1/insert", "/bai1/update", "/bai1/delete" })
public class Bai1Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Bai1Controller() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.getRequestDispatcher("bai1.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String url = request.getRequestURI();

		if (url.contains("bai1/insert")) {
			response.getWriter().println("<h1>Creating a Insert record ...</h1>");
		}
		else if (url.contains("bai1/update")) {
			response.getWriter().println("<h1>Update du lieu</h1>");
		}
		else if(url.contains("bai1/delete")) {
			response.getWriter().println("<h1>Delete du lieu</h1>");
		}
		
	}

}
