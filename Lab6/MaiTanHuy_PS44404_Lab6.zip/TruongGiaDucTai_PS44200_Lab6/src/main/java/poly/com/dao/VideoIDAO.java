package poly.com.dao;

import java.util.List;
import poly.com.entity.Video;

public interface VideoIDAO extends ICRUD<Video, String> {
    List<Video> findActiveVideos();
    
    List<Video> findTopNViewedVideos(int topN);
    
    List<Video> findByTitleKeyword(String keyword);
    
    List<Object[]> findTop10MostLiked();
    
    List<Video> findVideosNoLikes();
    
    List<Object[]>findSharedIn2024();
}