package poly.com.dao;

import java.util.List;
import poly.com.entity.Share;

public interface ShareIDAO extends ICRUD<Share, Long> {

    List<Share> findSharesByVideoId(String videoId);

    List<Share> findSharesByUserId(String userId);
    
    List<Object[]> getShareSummary();
}