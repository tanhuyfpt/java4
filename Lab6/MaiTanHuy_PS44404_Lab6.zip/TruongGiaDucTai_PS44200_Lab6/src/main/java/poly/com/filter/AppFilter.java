package poly.com.filter; 

import java.io.IOException;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import poly.com.filter.HttpFilter; // Import interface tùy chỉnh

@WebFilter(filterName = "AppFilter" , urlPatterns = {"/*"}) 
public class AppFilter implements HttpFilter { // Implement interface

	@Override
	public void doFilter(HttpServletRequest req, HttpServletResponse resp, FilterChain chain)
			throws IOException, ServletException {
        
        // Thiết lập chế độ mã hóa ký tự UTF-8
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        
		chain.doFilter(req, resp);
	}
}