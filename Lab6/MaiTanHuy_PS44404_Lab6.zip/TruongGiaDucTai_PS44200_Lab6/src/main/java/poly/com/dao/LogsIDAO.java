package poly.com.dao;
import poly.com.entity.Logs;

public interface LogsIDAO extends ICRUD<Logs, Long> {
    // Chỉ cần kế thừa ICRUD vì yêu cầu chỉ là CREATE (ghi Log)
}