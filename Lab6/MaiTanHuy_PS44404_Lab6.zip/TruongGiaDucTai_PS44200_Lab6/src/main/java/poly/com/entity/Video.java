package poly.com.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.OneToMany; 
import lombok.Data;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "Videos")
public class Video {
    @Id
    @Column(name = "Id")
    private String id;

    @Column(name = "Title", nullable = false)
    private String title;

    @Column(name = "Poster")
    private String poster;

    @Column(name = "Views")
    private Integer views = 0; 

    @Column(name = "Description")
    private String description;
    
    @Column(name = "Category")
    private String category;
    
    @Column(name = "Active")
    private Boolean active = true; 

    @OneToMany(mappedBy = "video") 
    private List<Favorite> favorites;
    
    @OneToMany(mappedBy = "video")
    private List<Share> shares;
}