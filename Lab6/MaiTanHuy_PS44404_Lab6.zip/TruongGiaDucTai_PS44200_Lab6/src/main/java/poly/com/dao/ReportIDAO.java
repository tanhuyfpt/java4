package poly.com.dao;

import java.util.List;
import poly.com.entity.Report;

public interface ReportIDAO extends ICRUD<Report, Integer> {
    // Lưu ý: Key của Report là Integer (INT)

    // 1. Truy vấn các báo cáo theo tên nhóm (Groupp)
    List<Report> findReportsByGroup(String groupName);

    // 2. Truy vấn các báo cáo được tạo trong một năm cụ thể
    List<Report> findReportsByYear(int year);
}