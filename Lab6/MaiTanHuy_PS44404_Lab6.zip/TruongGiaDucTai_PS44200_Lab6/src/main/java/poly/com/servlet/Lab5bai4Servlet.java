package poly.com.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import poly.com.dao.*;
import java.util.List;


/**
 * Servlet implementation class Lab5bai4Servlet
 */
@WebServlet("/video/share-summary")
public class Lab5bai4Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ShareIDAO shareDao = new ShareDAOImpl();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Lab5bai4Servlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Object[]> shareSummary = shareDao.getShareSummary();
        request.setAttribute("shareSummary", shareSummary);
        request.getRequestDispatcher("/views/video_share_summary.jsp").forward(request, response);
    }

}
