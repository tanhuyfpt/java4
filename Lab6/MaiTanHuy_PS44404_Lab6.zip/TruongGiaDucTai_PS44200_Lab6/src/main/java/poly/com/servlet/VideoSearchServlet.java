package poly.com.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import poly.com.dao.*;
import poly.com.entity.Video;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/video/search")
public class VideoSearchServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private VideoIDAO videoDao = new VideoDAOImpl();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String keyword = request.getParameter("keyword");
        List<Video> videos = new ArrayList<>();

        if (keyword != null && !keyword.trim().isEmpty()) {
            videos = videoDao.findByTitleKeyword(keyword.trim());
        }

        request.setAttribute("videos", videos);
        request.setAttribute("keyword", keyword);
        request.getRequestDispatcher("/views/video_search.jsp").forward(request, response);
    }
}
