package poly.com.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;

import poly.com.utils.CookieUtils;
import poly.com.dao.*;
import poly.com.entity.User;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet({"/auth/login", "/auth/logout"})
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserIDAO userDao = new UserDAOImpl();
    
    private static final String SECURITY_URI_KEY = "securityUri"; 

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String uri = request.getRequestURI();
        
        // 1. Xử lý Logout nếu URL là /auth/logout
        if (uri.contains("/auth/logout")) {
            
            request.getSession().invalidate();
            
            // Xóa TẤT CẢ các Cookie liên quan đến Ghi nhớ/Đăng nhập
            CookieUtils.remove(request, response, "term"); 
            CookieUtils.remove(request, response, "remember");
            CookieUtils.remove(request, response, "passwordID"); 
            CookieUtils.remove(request, response, "userID"); // Xóa tất cả các tên cookie khả dĩ
            
            response.sendRedirect(request.getContextPath() + "/index");
            return;
        }

        // 2. Xử lý hiển thị form Login (với pre-fill từ Cookie)
        // ✅ ĐÃ SỬA: Đọc tất cả các cookie cần thiết để pre-fill form
        Cookie cTerm = CookieUtils.get(request, "term");
        Cookie cPass = CookieUtils.get(request, "passwordID");
        Cookie cRem = CookieUtils.get(request, "remember");
        
        if (cTerm != null) {
            request.setAttribute("term", cTerm.getValue());
        }
        if (cPass != null) {
            // Cảnh báo: Lưu mật khẩu (dù đã được mã hóa nếu có) trong cookie là không an toàn
            request.setAttribute("passwordID", cPass.getValue()); 
        }
        // Kiểm tra cờ ghi nhớ để check checkbox
        if (cRem != null) {
            request.setAttribute("rememberMeChecked", "true"); 
        }

        request.getRequestDispatcher("/views/login.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        
        String term = request.getParameter("term"); 
        String password = request.getParameter("password");
        String rememberMeParam = request.getParameter("rememberMe"); 

        User user = userDao.findByIdOrEmail(term);

        if (user != null && user.getPassword().equals(password)) {
            // Đăng nhập thành công
            HttpSession session = request.getSession();
            session.setAttribute("userLogin", user);
            
            // Logic xử lý lưu/xóa Cookie "Remember Me"
            if (rememberMeParam != null) {
                // Lưu cookie (30 ngày * 24 giờ)
                CookieUtils.add(response, "term", term, 30); 
                // ✅ ĐÃ THÊM: Lưu cookie mật khẩu
                CookieUtils.add(response, "passwordID", password,  30); 
                CookieUtils.add(response, "remember", "true", 30);

            } else {
                // Xóa cookie nếu không chọn Remember Me
                CookieUtils.remove(request, response, "term");
                CookieUtils.remove(request, response, "remember");
                
                // Xóa cả passwordID và userID khi không chọn ghi nhớ
                CookieUtils.remove(request, response, "passwordID"); 
                CookieUtils.remove(request, response, "userID");
            }
            
            String securityUri = (String) session.getAttribute(SECURITY_URI_KEY);
            session.removeAttribute(SECURITY_URI_KEY);
            
            if (securityUri != null && !securityUri.isEmpty()) {
                response.sendRedirect(securityUri);
            } else {
                response.sendRedirect(request.getContextPath() + "/index"); 
            }

        } else {
            // Đăng nhập thất bại
            request.setAttribute("error", "Username/email hoặc mật khẩu không đúng!");
            request.setAttribute("term", term);
            
            if (rememberMeParam != null) {
                request.setAttribute("rememberMeChecked", "true"); 
            }
            
            request.getRequestDispatcher("/views/login.jsp").forward(request, response);
        }
    }
}