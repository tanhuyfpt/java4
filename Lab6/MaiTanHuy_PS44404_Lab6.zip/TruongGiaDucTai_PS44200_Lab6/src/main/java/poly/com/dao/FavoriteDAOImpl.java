package poly.com.dao;

import java.util.List;
import jakarta.persistence.TypedQuery;
import poly.com.entity.Favorite;
import poly.com.entity.User;
import poly.com.entity.Video;
import java.util.List;
import jakarta.persistence.TypedQuery;
import poly.com.entity.Favorite;

public class FavoriteDAOImpl extends AbstractDAO<Favorite, Long> implements FavoriteIDAO {

    public FavoriteDAOImpl() {
        super(Favorite.class);
    }

    @Override
    public List<Video> findFavoriteVideosByUserId(String userId) {
        return executeQuery(em -> {
            String jpql = "SELECT f.video FROM Favorite f WHERE f.user.id = :userId";
            TypedQuery<Video> query = em.createQuery(jpql, Video.class); 
            query.setParameter("userId", userId);
            return query.getResultList();
        });
    }

    @Override
    public List<Favorite> findAllFavoritesByVideoId(String videoId) {
        return executeQuery(em -> {
            String jpql = "SELECT f FROM Favorite f WHERE f.video.id = :videoId ORDER BY f.likeDate DESC";
            TypedQuery<Favorite> query = em.createQuery(jpql, Favorite.class);
            query.setParameter("videoId", videoId);
            return query.getResultList();
        });
    }
    
    @Override
    public List<Favorite> findAllWithDetails() {
        return executeQuery(em -> {
            // Sử dụng JOIN FETCH để tải User và Video cùng lúc, giải quyết lỗi Lazy Loading
            String jpql = "SELECT f FROM Favorite f " 
                        + "JOIN FETCH f.user u "      // JOIN FETCH User
                        + "JOIN FETCH f.video v "     // JOIN FETCH Video
                        + "ORDER BY f.likeDate DESC";
            
            TypedQuery<Favorite> query = em.createQuery(jpql, Favorite.class);
            return query.getResultList();
        });
    }
    
    @Override
    public List<User> findUsersByVideoId(String videoId) {
        return executeQuery(em -> {
            // JOIN Favorite với User, lọc theo videoId, DISTINCT để tránh lặp User nếu họ thích nhiều lần
            String jpql = "SELECT DISTINCT f.user FROM Favorite f WHERE f.video.id = :videoId";
            TypedQuery<User> query = em.createQuery(jpql, User.class);
            query.setParameter("videoId", videoId);
            return query.getResultList();
        });
    }

}