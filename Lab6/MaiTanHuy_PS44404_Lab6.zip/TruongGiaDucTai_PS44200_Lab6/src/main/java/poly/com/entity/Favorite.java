package poly.com.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne; 
import jakarta.persistence.JoinColumn; 
import jakarta.persistence.Temporal; 
import jakarta.persistence.TemporalType; 
import lombok.Data;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import java.util.Date; 

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "Favorites")
public class Favorite {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) 
    @Column(name = "Id")
    private Long id; 

    @ManyToOne 
    @JoinColumn(name = "UserId", nullable = false) 
    private User user; 

    @ManyToOne
    @JoinColumn(name = "VideoId", nullable = false) 
    private Video video; 

    @Temporal(TemporalType.DATE) 
    @Column(name = "LikeDate")
    private Date likeDate = new Date();
}