package poly.com.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import jakarta.servlet.ServletException; // SỬ DỤNG jakarta
import jakarta.servlet.annotation.WebServlet; // SỬ DỤNG jakarta
import jakarta.servlet.http.HttpServlet; // SỬ DỤNG jakarta
import jakarta.servlet.http.HttpServletRequest; // SỬ DỤNG jakarta
import jakarta.servlet.http.HttpServletResponse; // SỬ DỤNG jakarta

// Import các lớp Model và Utility của bạn
import poly.com.model.Employee; 
// Import poly.com.util.RestIO (Đảm bảo đã tạo lớp tiện ích này)
import poly.com.util.RestIO; 

@WebServlet("/employees/*") // Đảm bảo đường dẫn là /employees/*
public class EmployeeRestServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    // Dữ liệu mẫu (Giả lập Database)
    private Map<String, Employee> map = new HashMap<>();

    // Khởi tạo dữ liệu mẫu
    @Override
    public void init() throws ServletException {
        map.put("NV01", new Employee("NV01", "Nguyễn Văn A", true, 1000.0f));
        map.put("NV02", new Employee("NV02", "Trần Thị B", false, 1200.5f));
        map.put("NV03", new Employee("NV03", "Lê Văn C", true, 950.0f));
    }

    // GET: /employees hoặc GET: /employees/ID
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String info = req.getPathInfo();
        
        if(info == null || info.length() == 0 || info.equals("/")) {
            // GET: /employees - Lấy tất cả
            RestIO.writeObject(resp, map.values()); 
        } else {
            // GET: /employees/ID - Lấy theo ID
            String id = info.substring(1).trim();
            Employee employee = map.get(id);
            if (employee != null) {
                RestIO.writeObject(resp, employee);
            } else {
                resp.setStatus(HttpServletResponse.SC_NOT_FOUND); // 404
                RestIO.writeEmptyObject(resp);
            }
        }
    }

    // POST: /employees - Thêm nhân viên mới
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        // Đọc JSON từ request và chuyển thành đối tượng Employee
        Employee employee = RestIO.readObject(req, Employee.class);
        
        // Kiểm tra trùng lặp
        if (map.containsKey(employee.getManv())) {
             resp.setStatus(HttpServletResponse.SC_CONFLICT); // 409 Conflict
             RestIO.writeEmptyObject(resp);
             return;
        }
        
        map.put(employee.getManv(), employee);
        resp.setStatus(HttpServletResponse.SC_CREATED); // 201 Created
        RestIO.writeObject(resp, employee);
    }

    // PUT: /employees/ID - Cập nhật nhân viên
    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String info = req.getPathInfo();
        if(info == null || info.length() <= 1) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST); // 400 Bad Request
            RestIO.writeEmptyObject(resp);
            return;
        }
        
        String id = info.substring(1).trim();
        Employee employee = RestIO.readObject(req, Employee.class);
        
        if (!map.containsKey(id)) {
            resp.setStatus(HttpServletResponse.SC_NOT_FOUND); // 404
            RestIO.writeEmptyObject(resp);
            return;
        }

        map.put(id, employee);
        resp.setStatus(HttpServletResponse.SC_NO_CONTENT); // 204 No Content
        RestIO.writeEmptyObject(resp); 
    }

    // DELETE: /employees/ID - Xóa nhân viên
    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String info = req.getPathInfo();
        if(info == null || info.length() <= 1) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST); // 400 Bad Request
            RestIO.writeEmptyObject(resp);
            return;
        }
        
        String id = info.substring(1).trim();
        
        if (map.remove(id) != null) {
            resp.setStatus(HttpServletResponse.SC_NO_CONTENT); // 204 No Content
        } else {
            resp.setStatus(HttpServletResponse.SC_NOT_FOUND); // 404
        }
        RestIO.writeEmptyObject(resp);
    }
}