package poly.com.servlet;

import java.util.List;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.TypedQuery;
import poly.com.model.User;

public class Testketnoi {

	public static void main(String[] args)
	{
		// 
		//create();
		//delete();
		//findAll();
		//findByRole(true);
		findPage(0,3);
		
	}
	
	
	private static void findAll() {
	    EntityManagerFactory emf = null;
	    EntityManager em = null;

	    try {
	        // Nạp persistence unit
	        emf = Persistence.createEntityManagerFactory("PolyOE");
	        em = emf.createEntityManager();
	        // JPQL: chú ý tên entity là User (không dùng keyword SQL)
	        String jpql = "SELECT u FROM User u";
	        TypedQuery<User> query = em.createQuery(jpql, User.class);
	        List<User> list = query.getResultList();

	        for (User user : list) {
	            System.out.println(">> Email: " + user.getEmail());
	            System.out.println(">> Quyen: " + user.getAdmin());
	            System.out.println(">> ID: " + user.getId());
	            System.out.println(">> Password: " + user.getPassword());
	            System.out.println(">> Ten day du: " + user.getFullname());
	            System.out.println("----------------------------");
	        }

	        System.out.println("Truy vấn thành công!");

	    }
	    catch (Exception e) {
	        System.out.println("Truy vấn thất bại!");
	        e.printStackTrace(); // In ra chi tiết lỗi
	    } finally {
	        if (em != null && em.isOpen()) {
	            em.close();
	        }
	        if (emf != null && emf.isOpen()) {
	            emf.close();
	        }
	    }
	}

	private static void create() { // CREATE = INSERT
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PolyOE");
		EntityManager em = emf.createEntityManager();
		try
		{
			em.getTransaction().begin(); 
			User entity = new User();
			
			entity.setId("nv1213");
			entity.setEmail("TULA20@FE.EDU.VN");
			entity.setPassword("abc");
			entity.setFullname("HELLO SD306");
			entity.setAdmin(true);
			// Insert vÃƒÂ o CSDL
			em.persist(entity);  // them vao database

			em.getTransaction().commit(); // 
			
			System.out.println("thêm thành công !");
		} catch (Exception e) {
			em.getTransaction().rollback(); // HÃ¡Â»Â§y thao tÃƒÂ¡c
			System.out.println("fail");
		}
		em.close();
		emf.close();
	}
	
	
//
private static void delete() {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PolyOE");
		EntityManager em = emf.createEntityManager();
		try {
			em.getTransaction().begin(); 

			User entity = em.find(User.class, "nv1213");
			em.remove(entity);// xoa

			em.getTransaction().commit(); // chap nhan ket qua thao tac
			System.out.println("Delete thành công!");
		}
		catch (Exception e) {
			em.getTransaction().rollback(); // huy thao tac
			System.out.println("Delete thất bại!");
		}
		em.close();
		emf.close();
	}

	//
private static void update() {
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("PolyOE");
	EntityManager em = emf.createEntityManager();
try
			{
			em.getTransaction().begin(); // 
			
			User entity = em.find(User.class, "nv01");
			entity.setPassword("ILOVEYOU");
			entity.setAdmin(false);
			entity.setFullname("ĐÀM VĨNH HƯNG");
			em.merge(entity);// cap nhat
			
			em.getTransaction().commit(); // ChÃ¡ÂºÂ¥p nhÃ¡ÂºÂ­n kÃ¡ÂºÂ¿t quÃ¡ÂºÂ£ thao tÃƒÂ¡c
			System.out.println("Update thanh cong!");
			}
			catch (Exception e) {
			em.getTransaction().rollback(); // HÃ¡Â»Â§y thao tÃƒÂ¡c
			System.out.println("Update that bai");
			}
			em.close();
			emf.close();
}
	// các câu lệnh tìm kiếm

private static void findByRole(boolean role) {
	// nap 
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("PolyOE");
	EntityManager em = emf.createEntityManager();
	try {
		String jpql = "SELECT o FROM User o WHERE o.Admin=:role";
		TypedQuery<User> query = em.createQuery(jpql, User.class);
		query.setParameter("role", role);

		// Truy vÃ¡ÂºÂ¥n
		List<User> list = query.getResultList();

		// HiÃ¡Â»Æ’n thÃ¡Â»â€¹ kÃ¡ÂºÂ¿t quÃ¡ÂºÂ£ truy vÃ¡ÂºÂ¥n
		for (User user : list) {
			System.out.println(">>Email: " + user.getEmail());
			System.out.println(">>Is Admin: " + user.getAdmin());
		}
		System.out.println("Truy van thanh cong!");
	} catch (Exception e) {
		System.out.println("Truy van loi!");
	}
	em.close();
	emf.close();
}

private static void findByKeyword(String email, String fullname ) {
	// NÃ¡ÂºÂ¡p persistence.xml vÃƒÂ  tÃ¡ÂºÂ¡o EntityManagerFactory
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("PolyOE");
	// TÃ¡ÂºÂ¡o EntityManager Ã„â€˜Ã¡Â»Æ’ bÃ¡ÂºÂ¯t Ã„â€˜Ã¡ÂºÂ§u lÃƒÂ m viÃ¡Â»â€¡c vÃ¡Â»â€ºi CSDL
	EntityManager em = emf.createEntityManager();
	try {
		// MÃƒÆ’ THAO TÃƒï¿½C
		// CÃƒÂ¢u lÃ¡Â»â€¡nh truy vÃ¡ÂºÂ¥n JPQL
		String jpql = "SELECT o FROM User o WHERE o.Email LIKE ?0 OR o.Fullname LIKE ?1";
		// TÃ¡ÂºÂ¡o Ã„â€˜Ã¡Â»â€˜i tÃ†Â°Ã¡Â»Â£ng truy vÃ¡ÂºÂ¥n
		TypedQuery<User> query = em.createQuery(jpql, User.class);
		query.setParameter(0, email);
		query.setParameter(1, fullname);
		// Truy vÃ¡ÂºÂ¥n
		List<User> list = query.getResultList();
		
		// HiÃ¡Â»Æ’n thÃ¡Â»â€¹ kÃ¡ÂºÂ¿t quÃ¡ÂºÂ£ truy vÃ¡ÂºÂ¥n
		for (User user : list) {
			System.out.println(">>Email: " + user.getEmail());
			System.out.println(">>Is Admin: " + user.getAdmin());
		}
		System.out.println("Truy van thanh cong!");
	} catch (Exception e) {
		System.out.println("Truy van that bai!");
	}
	em.close();
	emf.close();
}

///
private static void findByFullname(String fullname) {
    // Nạp EntityManagerFactory
    EntityManagerFactory emf = Persistence.createEntityManagerFactory("PolyOE");
    EntityManager em = emf.createEntityManager();
    try {
        // Câu lệnh truy vấn JPQL để tìm theo tên
        String jpql = "SELECT o FROM User o WHERE o.Fullname LIKE :fullname";
        // Tạo đối tượng truy vấn
        TypedQuery<User> query = em.createQuery(jpql, User.class);
        query.setParameter("fullname", "%" + fullname + "%"); // Dùng LIKE để tìm gần đúng

        // Truy vấn và lấy kết quả
        List<User> list = query.getResultList();

        // Hiển thị kết quả
        for (User user : list) {
            System.out.println(">>Email: " + user.getEmail());
            System.out.println(">>Fullname: " + user.getFullname());
            System.out.println(">>Is Admin: " + user.getAdmin());
        }
        System.out.println("Truy vấn thành công!");
    } catch (Exception e) {
        System.out.println("Truy vấn thất bại! Lỗi: " + e.getMessage());
    } finally {
        em.close();
        emf.close();
    }
}	
	
	// phan trang

private static void findPage(int page, int size) {
	
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("PolyOE");
	EntityManager em = emf.createEntityManager();
	try {
		
		String jpql = "SELECT o FROM User o";
		// vi du co 100 phan tu
		// truyen page = 3, size = 15 >> co nghia la muon lay 15 phan tu bat dau tu phan tu thu 3
		
		TypedQuery<User> query = em.createQuery(jpql, User.class);
		query.setFirstResult(page * size);
		query.setMaxResults(size);
	
		List<User> list = query.getResultList();
	
		for(User user: list) {
			System.out.println(">>Email: " + user.getEmail());
			System.out.println(">>Is Admin: " + user.getAdmin());
		}

		System.out.println("Truy van thanh cong!");
	} catch (Exception e) {
		System.out.println("Truy van that bai!");
	}
	em.close();
	emf.close();
}
//

}
