var websocket = null; // biến giữ đối tượng WebSocket 

// Gọi khi trang load
function init() { 
  // Kết nối đến chat server WebSocket
  websocket = new WebSocket('ws://localhost:8080/Lab8_sof3012_socket/text/chat'); 
  
  // Khi kết nối thành công
  websocket.onopen = function(resp) {
    console.log("onopen", resp);
  }

  // Khi nhận tin nhắn từ server
  websocket.onmessage = function(resp) {
    var message = resp.data;
    var html = document.getElementById('messages').innerHTML;
    document.getElementById('messages').innerHTML = `${html}<p>${message}</p>`;
    console.log("onmessage", resp.data);
  }

  // Khi có lỗi xảy ra
  websocket.onerror = function(resp) {
    alert('An error occurred, closing application');
    console.log("onerror", resp);
  }

  // Khi server đóng kết nối
  websocket.onclose = function(resp) {
    alert(resp.reason || 'Goodbye');
    console.log("onclose", resp);
  }
}

// Gửi tin nhắn đến server
function send() {
  var message = document.getElementById("message").value;
  if (websocket && websocket.readyState === WebSocket.OPEN) {
    websocket.send(message);
    document.getElementById("message").value = '';
  } else {
    alert("WebSocket is not connected.");
  }
}
