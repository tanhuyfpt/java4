package poly.com.servlet;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.websocket.EncodeException;
import jakarta.websocket.Encoder;
import poly.com.model.Message;

public class MessageEncoder implements Encoder.Text<Message>
{
private ObjectMapper mapper = new ObjectMapper();
@Override
public void destroy() {}
	@Override
	public String encode(Message message) throws EncodeException {
		// TODO Auto-generated method stub
	try
	{
		return mapper.writeValueAsString(message);
	}
	catch(JsonProcessingException e)
	{
		throw new EncodeException(message, "unendocde");
		
	}
	
	}

	
}
