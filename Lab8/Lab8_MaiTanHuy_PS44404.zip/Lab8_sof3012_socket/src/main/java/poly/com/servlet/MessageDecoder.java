package poly.com.servlet;

import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.websocket.DecodeException;
import jakarta.websocket.Decoder;
import jakarta.websocket.EndpointConfig;
import poly.com.model.Message;

import java.io.IOException;

public class MessageDecoder implements Decoder.Text<Message> {

    private ObjectMapper mapper = new ObjectMapper(); // Sử dụng ObjectMapper để chuyển đổi JSON

    // Phương thức này không cần xử lý gì, thường để chuẩn bị cấu hình (nếu có)
    @Override
    public void init(EndpointConfig config) {}

    // Phương thức này sẽ được gọi khi kết thúc, có thể dọn dẹp tài nguyên nếu cần
    @Override
    public void destroy() {}

    // Phương thức chính dùng để decode JSON thành đối tượng Message
    @Override
    public Message decode(String json) throws DecodeException {
        try {
            // Chuyển đổi chuỗi JSON thành đối tượng Message
            return mapper.readValue(json, Message.class);
        } catch (IOException e) {
            // Nếu lỗi xảy ra khi decode JSON, throw lỗi DecodeException
            throw new DecodeException(json, "Unable to decode JSON to Message", e);
        }
    }

    // Phương thức này dùng để kiểm tra xem liệu chuỗi JSON có thể được giải mã thành đối tượng Message hay không
    @Override
    public boolean willDecode(String json) {
        return json != null && json.contains("text");
    }

}
